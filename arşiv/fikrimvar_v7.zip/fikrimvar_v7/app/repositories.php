<?php
declare(strict_types=1);

function categories(bool $activeOnly=true): array
{
    $sql='SELECT * FROM categories';
    if ($activeOnly) $sql.=' WHERE is_active=1';
    $sql.=' ORDER BY sort_order, title';
    return db()->query($sql)->fetchAll();
}

function channels(): array
{
    return db()->query('SELECT * FROM channels WHERE is_active=1 AND url<>\'\' ORDER BY sort_order,id')->fetchAll();
}

function project_row_to_view(array $row): array
{
    $row['slug']=(string)$row['slug'];
    $row['category']=$row['category_slug'] ?? '';
    $row['category_label']=$row['category_title'] ?? '';
    $row['cover']=media_url($row['cover_path'] ?? '');
    $row['kind']=($row['workshop_status'] ?? 'none')==='open' ? 'atelier' : 'story';
    $row['public'] = ($row['visibility'] ?? '')==='public';
    $row['homepage']=(bool)($row['show_on_home'] ?? false);
    $row['order']=$row['sort_order'] ?? 999;
    return $row;
}

function public_projects(bool $archiveOnly=false): array
{
    $sql="SELECT p.*, c.slug category_slug, c.title category_title, m.relative_path cover_path,
                  s.id story_id, s.status story_status, s.visibility story_visibility,
                  s.reading_time, s.title story_title, s.question story_question, s.summary story_summary,
                  s.show_on_home story_show_on_home, s.show_in_archive story_show_in_archive, s.sort_order story_sort_order
           FROM projects p
           LEFT JOIN categories c ON c.id=p.category_id
           LEFT JOIN media m ON m.id=p.cover_media_id AND m.deleted_at IS NULL
           LEFT JOIN stories s ON s.project_id=p.id AND s.deleted_at IS NULL
           WHERE p.deleted_at IS NULL AND p.visibility='public' ";
    if ($archiveOnly) $sql.=' AND p.show_in_archive=1 ';
    $sql.=" AND ((s.status='published' AND s.visibility='public') OR p.workshop_status='open')";
    $sql.=' ORDER BY p.is_pinned DESC, p.sort_order ASC, COALESCE(p.updated_at,p.created_at) DESC';
    $rows=db()->query($sql)->fetchAll();
    $out=[];
    foreach ($rows as $r) {
        if (($r['story_status'] ?? '')==='published') {
            $r['title']=$r['story_title'] ?: $r['title'];
            $r['question']=$r['story_question'] ?: $r['question'];
            $r['summary']=$r['story_summary'] ?: $r['summary'];
        }
        $out[$r['slug']]=project_row_to_view($r);
    }
    return $out;
}

function project_by_slug(string $slug, bool $admin=false): ?array
{
    $sql="SELECT p.*, c.slug category_slug, c.title category_title, m.relative_path cover_path,
                  s.id story_id, s.status story_status, s.visibility story_visibility,
                  s.title story_title, s.question story_question, s.summary story_summary,
                  s.reading_time, s.show_on_home story_show_on_home, s.show_in_archive story_show_in_archive,
                  s.is_pinned story_is_pinned, s.sort_order story_sort_order, s.published_at story_published_at
           FROM projects p
           LEFT JOIN categories c ON c.id=p.category_id
           LEFT JOIN media m ON m.id=p.cover_media_id AND m.deleted_at IS NULL
           LEFT JOIN stories s ON s.project_id=p.id AND s.deleted_at IS NULL
           WHERE p.slug=? AND p.deleted_at IS NULL";
    if (!$admin) $sql.=" AND p.visibility IN ('public','unlisted')";
    $st=db()->prepare($sql); $st->execute([$slug]); $r=$st->fetch();
    if (!$r) return null;
    if (($r['story_status'] ?? '')==='published') {
        $r['title']=$r['story_title'] ?: $r['title'];
        $r['question']=$r['story_question'] ?: $r['question'];
        $r['summary']=$r['story_summary'] ?: $r['summary'];
    }
    $r=project_row_to_view($r);
    $r['tags']=project_tags((int)$r['id']);
    return $r;
}

function project_tags(int $projectId): array
{
    $st=db()->prepare('SELECT t.name FROM tags t JOIN project_tags pt ON pt.tag_id=t.id WHERE pt.project_id=? ORDER BY t.name');
    $st->execute([$projectId]); return array_column($st->fetchAll(),'name');
}

function story_url(array $project): string
{
    $slug=rawurlencode((string)$project['slug']);
    if (($project['workshop_status'] ?? 'none')==='open' && ($project['story_status'] ?? '')!=='published') return 'atolye.php?slug='.$slug;
    return 'hikaye.php?slug='.$slug;
}

function story_by_project(int $projectId, bool $admin=false): ?array
{
    $sql='SELECT * FROM stories WHERE project_id=? AND deleted_at IS NULL';
    if (!$admin) $sql.=" AND status='published' AND visibility IN ('public','unlisted')";
    $st=db()->prepare($sql); $st->execute([$projectId]); return $st->fetch() ?: null;
}

function story_sections(int $storyId): array
{
    $st=db()->prepare("SELECT ss.*, m.relative_path media_path, m.alt_text media_alt, m.caption media_caption, m.media_type
      FROM story_sections ss LEFT JOIN media m ON m.id=ss.media_id AND m.deleted_at IS NULL
      WHERE ss.story_id=? AND ss.deleted_at IS NULL ORDER BY ss.sort_order,ss.id");
    $st->execute([$storyId]); $sections=$st->fetchAll();
    $itemSt=db()->prepare("SELECT i.*, m.relative_path media_path, m.alt_text media_alt, m.caption media_caption, m.media_type
      FROM story_section_items i LEFT JOIN media m ON m.id=i.media_id AND m.deleted_at IS NULL
      WHERE i.section_id=? ORDER BY i.sort_order,i.id");
    $mediaSt=db()->prepare("SELECT sm.*,m.relative_path,m.alt_text,m.caption,m.media_type,m.title
      FROM story_section_media sm JOIN media m ON m.id=sm.media_id AND m.deleted_at IS NULL
      WHERE sm.section_id=? ORDER BY sm.sort_order,sm.id");
    $linkSt=db()->prepare("SELECT * FROM links WHERE owner_type='story_section' AND owner_id=? ORDER BY sort_order,id");
    foreach ($sections as &$s) {
        $itemSt->execute([$s['id']]); $s['items']=$itemSt->fetchAll();
        $mediaSt->execute([$s['id']]); $s['media']=$mediaSt->fetchAll();
        $linkSt->execute([$s['id']]); $s['links']=$linkSt->fetchAll();
    }
    unset($s); return $sections;
}

function project_updates(int $projectId, bool $publishedOnly=true): array
{
    $sql='SELECT * FROM updates WHERE project_id=? AND deleted_at IS NULL';
    if ($publishedOnly) $sql.=" AND status='published' AND visibility IN ('public','unlisted')";
    $sql.=' ORDER BY COALESCE(work_date,created_at),sort_order,id';
    $st=db()->prepare($sql); $st->execute([$projectId]); $rows=$st->fetchAll();
    foreach ($rows as &$r) {
        $r['media']=update_media((int)$r['id']);
        $r['links']=owner_links('update',(int)$r['id']);
        $r['_id']=$r['slug'];
        $r['date_label']=$r['display_label'] ?: ($r['work_date'] ? date('d.m.Y',strtotime($r['work_date'])) : '');
        $r['day']=$r['display_label'];
        $r['next']=$r['next_step'];
    }
    unset($r); return $rows;
}

function update_media(int $updateId): array
{
    $st=db()->prepare("SELECT um.*,m.relative_path,m.alt_text,m.caption,m.media_type,m.title,m.mime_type
      FROM update_media um JOIN media m ON m.id=um.media_id AND m.deleted_at IS NULL
      WHERE um.update_id=? ORDER BY um.sort_order,um.id");
    $st->execute([$updateId]); return $st->fetchAll();
}

function owner_links(string $type, int $ownerId): array
{
    $st=db()->prepare('SELECT * FROM links WHERE owner_type=? AND owner_id=? ORDER BY sort_order,id');
    $st->execute([$type,$ownerId]); return $st->fetchAll();
}

function recent_updates(int $limit=4): array
{
    $limit=max(1,min(20,$limit));
    $sql="SELECT u.*, p.slug project_slug,p.title project_title,p.question project_question,p.summary project_summary,
                  p.status_label,p.type_label,p.workshop_status,p.visibility,p.id project_id,
                  c.slug category_slug,c.title category_title,m.relative_path cover_path,
                  s.status story_status,s.reading_time
      FROM updates u JOIN projects p ON p.id=u.project_id AND p.deleted_at IS NULL
      LEFT JOIN categories c ON c.id=p.category_id
      LEFT JOIN media m ON m.id=p.cover_media_id AND m.deleted_at IS NULL
      LEFT JOIN stories s ON s.project_id=p.id AND s.deleted_at IS NULL
      WHERE u.deleted_at IS NULL AND u.status='published' AND u.visibility='public' AND u.show_in_recent=1 AND p.visibility='public'
      ORDER BY COALESCE(u.work_date,u.published_at,u.created_at) DESC,u.id DESC LIMIT ".$limit;
    $rows=db()->query($sql)->fetchAll(); $out=[];
    foreach ($rows as $u) {
        $p=project_row_to_view([
            'id'=>$u['project_id'],'slug'=>$u['project_slug'],'title'=>$u['project_title'],'question'=>$u['project_question'],
            'summary'=>$u['project_summary'],'status_label'=>$u['status_label'],'type_label'=>$u['type_label'],
            'workshop_status'=>$u['workshop_status'],'visibility'=>$u['visibility'],'category_slug'=>$u['category_slug'],
            'category_title'=>$u['category_title'],'cover_path'=>$u['cover_path'],'story_status'=>$u['story_status'],'reading_time'=>$u['reading_time']
        ]);
        $u['links']=owner_links('update',(int)$u['id']);
        $u['_id']=$u['slug']; $u['date_label']=$u['display_label'] ?: ($u['work_date'] ? date('d.m.Y',strtotime($u['work_date'])) : '');
        $out[]=['update'=>$u,'story'=>$p];
    }
    return $out;
}

function pinned_workshop(): ?array
{
    $st=db()->query("SELECT slug FROM projects WHERE deleted_at IS NULL AND visibility='public' AND workshop_status='open' AND show_in_widget=1 ORDER BY is_pinned DESC,sort_order LIMIT 1");
    $slug=$st->fetchColumn(); return $slug ? project_by_slug((string)$slug) : null;
}

function public_notes(): array
{
    return db()->query("SELECT name,message,created_at FROM notes WHERE status='published' ORDER BY published_at DESC,id DESC LIMIT 50")->fetchAll();
}

function count_public(string $kind): int
{
    return match($kind) {
        'stories' => (int)db()->query("SELECT COUNT(*) FROM stories s JOIN projects p ON p.id=s.project_id WHERE s.status='published' AND s.visibility='public' AND s.deleted_at IS NULL AND p.deleted_at IS NULL AND p.visibility='public'")->fetchColumn(),
        'workshops' => (int)db()->query("SELECT COUNT(*) FROM projects WHERE workshop_status='open' AND visibility='public' AND deleted_at IS NULL")->fetchColumn(),
        'methods' => (int)db()->query("SELECT COUNT(*) FROM projects p JOIN categories c ON c.id=p.category_id WHERE c.slug='yz-yontem' AND p.visibility='public' AND p.deleted_at IS NULL")->fetchColumn(),
        'unfinished' => (int)db()->query("SELECT COUNT(*) FROM projects WHERE status IN ('yarim','fikir','not') AND visibility='public' AND deleted_at IS NULL")->fetchColumn(),
        default => 0,
    };
}

function admin_projects(string $filter='all'): array
{
    $where='p.deleted_at IS NULL';
    if ($filter==='trash') $where='p.deleted_at IS NOT NULL';
    elseif ($filter==='workshop') $where.=" AND p.workshop_status IN ('open','paused')";
    elseif ($filter==='published') $where.=" AND s.status='published'";
    elseif ($filter==='draft') $where.=" AND (s.status='draft' OR s.id IS NULL)";
    $sql="SELECT p.*,c.title category_title,m.relative_path cover_path,s.id story_id,s.status story_status,s.visibility story_visibility,s.published_at story_published_at,
      (SELECT COUNT(*) FROM updates u WHERE u.project_id=p.id AND u.deleted_at IS NULL) update_count
      FROM projects p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN media m ON m.id=p.cover_media_id
      LEFT JOIN stories s ON s.project_id=p.id AND s.deleted_at IS NULL WHERE $where ORDER BY p.is_pinned DESC,p.sort_order,p.updated_at DESC";
    return db()->query($sql)->fetchAll();
}
