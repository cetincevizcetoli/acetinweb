<?php
declare(strict_types=1);

function render_paragraphs_text(string $text): void
{
    foreach (preg_split('/\R{2,}/u', trim($text)) ?: [] as $p) {
        $p=trim($p); if ($p!=='') echo '<p>'.e($p).'</p>';
    }
}

function render_story_section(array $section, int $index): void
{
    $type=(string)$section['type']; $layout=(string)$section['layout'];
    $number=str_pad((string)($index+1),2,'0',STR_PAD_LEFT);
    $id=$type==='questions' ? ' id="teknik"' : '';
    echo '<section class="story-block story-block--'.e($type).' story-layout--'.e($layout).'"'.$id.' data-reveal>';
    echo '<span class="story-block-number" aria-hidden="true">'.e($number).'</span>';
    $items=$section['items'] ?? [];
    $img=media_url($section['media_path'] ?? '');

    switch($type) {
        case 'opening':
        case 'split':
            echo '<div class="story-block-copy"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2>';
            render_paragraphs_text((string)$section['body_text']);
            if ($section['quote_text']!=='') echo '<blockquote>'.e($section['quote_text']).'</blockquote>';
            echo '</div>';
            if ($img!=='') echo '<figure class="story-block-media"><img src="'.e($img).'" alt="'.e($section['media_alt'] ?: $section['title']).'" loading="lazy"><figcaption>'.e($section['media_caption']).'</figcaption></figure>';
            break;
        case 'timeline':
            echo '<header class="story-block-heading"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2></header>';
            if ($img!=='') echo '<figure class="timeline-map"><img src="'.e($img).'" alt="'.e($section['media_alt'] ?: $section['title']).'" loading="lazy"></figure>';
            echo '<div class="timeline-track">';
            foreach($items as $it) echo '<article><span>'.e($it['step']).'</span><small>'.e($it['subtitle']).'</small><h3>'.e($it['title']).'</h3><p>'.e($it['text']).'</p></article>';
            echo '</div>'; break;
        case 'compare':
            echo '<header class="story-block-heading"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2><p>'.e($section['intro_text']).'</p></header><div class="compare-plane">';
            foreach(['left','right'] as $g) {
                $group=array_values(array_filter($items,fn($x)=>$x['group_key']===$g));
                $heading=''; foreach($group as $it) if($it['item_type']==='heading') $heading=$it['title'];
                echo '<div class="compare-column compare-column--'.e($g).'"><h3>'.e($heading).'</h3>';
                foreach($group as $it) if($it['item_type']==='bullet') echo '<p>'.e($it['text']).'</p>';
                echo '</div>';
            }
            echo '</div>'; break;
        case 'questions':
            echo '<header class="story-block-heading"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2></header><div class="question-stack">';
            foreach(array_values($items) as $i=>$it) echo '<details'.($i===0?' open':'').'><summary><span>'.str_pad((string)($i+1),2,'0',STR_PAD_LEFT).'</span>'.e($it['title']).'</summary><p>'.e($it['text']).'</p></details>';
            echo '</div>'; break;
        case 'roles':
            echo '<header class="story-block-heading"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2><p>'.e($section['note_text']).'</p></header><div class="role-cross">';
            foreach(['ai'=>'YAPAY ZEKÂ','human'=>'AHMET'] as $g=>$title) {
                echo '<div><small>'.$title.'</small>';
                foreach($items as $it) if($it['group_key']===$g) echo '<p>'.e($it['text']).'</p>';
                echo '</div>';
            }
            echo '</div>'; break;
        case 'status':
            echo '<header class="story-block-heading"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2></header><div class="status-orbit">';
            foreach($items as $it) echo '<article><small>'.e($it['state']).'</small><h3>'.e($it['title']).'</h3><p>'.e($it['text']).'</p></article>';
            echo '</div>'; break;
        case 'lesson':
            echo '<header class="story-block-heading"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2></header><ol class="lesson-list">';
            foreach($items as $it) echo '<li>'.e($it['text']).'</li>';
            echo '</ol>'; break;
        case 'code':
            echo '<div class="story-block-copy"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2><p>'.e($section['note_text']).'</p></div><pre class="code-window"><code>'.e($section['code_text']).'</code></pre>'; break;
        case 'gallery':
            echo '<header class="story-block-heading"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2></header><div class="story-gallery">';
            foreach($items as $it) { $p=media_url($it['media_path'] ?? ''); if($p==='') continue; echo '<figure><img src="'.e($p).'" alt="'.e($it['media_alt'] ?: $it['title']).'" loading="lazy"><figcaption>'.e($it['title'] ?: $it['media_caption']).'</figcaption></figure>'; }
            echo '</div>'; break;
        case 'video':
            echo '<div class="story-block-copy"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2>'; render_paragraphs_text((string)$section['body_text']); echo '</div>';
            foreach($section['media'] ?? [] as $m) { $p=media_url($m['relative_path']); if($m['media_type']==='video') echo '<video controls preload="metadata"><source src="'.e($p).'"></video>'; }
            foreach($section['links'] ?? [] as $l) echo '<p><a class="inline-link" href="'.e($l['url']).'" target="_blank" rel="noopener">'.e($l['title']).' '.icon('arrow').'</a></p>';
            break;
        default:
            echo '<div class="story-block-copy"><p class="eyebrow">'.e($section['label']).'</p><h2>'.e($section['title']).'</h2>'; render_paragraphs_text((string)$section['body_text']); echo '</div>';
    }
    echo '</section>';
}

function render_media_items(array $media, string $class='atelier-media-grid'): void
{
    if ($media===[]) return;
    echo '<div class="'.e($class).'">';
    foreach($media as $m) {
        $src=media_url($m['relative_path'] ?? ''); if($src==='') continue;
        if(($m['media_type'] ?? '')==='video') echo '<figure><video controls preload="metadata"><source src="'.e($src).'" type="'.e($m['mime_type'] ?? '').'"></video><figcaption>'.e($m['caption_override'] ?: $m['caption']).'</figcaption></figure>';
        elseif(($m['media_type'] ?? '')==='audio') echo '<figure><audio controls preload="metadata"><source src="'.e($src).'" type="'.e($m['mime_type'] ?? '').'"></audio><figcaption>'.e($m['caption_override'] ?: $m['caption']).'</figcaption></figure>';
        else echo '<figure><img src="'.e($src).'" alt="'.e($m['alt_text'] ?? '').'" loading="lazy"><figcaption>'.e($m['caption_override'] ?: $m['caption']).'</figcaption></figure>';
    }
    echo '</div>';
}

function render_external_links(array $links): void
{
    if($links===[]) return;
    echo '<nav class="content-links" aria-label="İlgili bağlantılar">';
    foreach($links as $l) echo '<a href="'.e($l['url']).'" target="_blank" rel="noopener noreferrer">'.e($l['title']).' '.icon('arrow').'</a>';
    echo '</nav>';
}
