FikrimVar V6.5 Hero hareket düzeltmesi

Sorun:
.hero-core--organic kapsayıcısının içindeki tüm PNG katmanları absolute olduğu için
kapsayıcının yüksekliği 0 px kalıyordu. Dosyalar yükleniyor ve JS çalışıyor olsa bile
çatlak/tel katmanları görünmüyordu.

Çözüm:
style.css sonuna aşağıdaki kural eklendi:

.hero-core--organic {
  aspect-ratio: 2048 / 1117;
}

Kurulum:
Bu paketteki assets/css/style.css dosyasını mevcut V6.5 içindeki aynı dosyanın yerine koyun.
Sonra Ctrl+F5 ile sert yenileme yapın.
